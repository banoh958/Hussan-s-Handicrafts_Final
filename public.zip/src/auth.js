// src/auth.js
import { auth, db } from './firebase-config';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendEmailVerification,
  signOut
} from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

/**
 * Sign up a new user, send verification email, and store profile in sessionStorage.
 */
export async function signUpUser(profile) {
  const { fullname, email, password, interests, experience } = profile;
  // Save pending profile until verification
  sessionStorage.setItem(
    'pendingProfile',
    JSON.stringify({ fullname, email, interests, experience, createdAt: new Date().toISOString() })
  );

  const { user } = await createUserWithEmailAndPassword(auth, email, password);
  await sendEmailVerification(user);
  await signOut(auth);
  return user;
}

/**
 * Sign in user, check verification, and write to Firestore if first verified sign in.
 */
export async function signInUser(email, password) {
  const { user } = await signInWithEmailAndPassword(auth, email, password);
  if (!user.emailVerified) {
    await signOut(auth);
    throw new Error('Email not verified. Please check your inbox.');
  }

  // On first verified sign-in, write profile to Firestore
  const pending = sessionStorage.getItem('pendingProfile');
  if (pending) {
    const profile = JSON.parse(pending);
    await setDoc(doc(db, 'users', user.uid), profile);
    sessionStorage.removeItem('pendingProfile');
  }

  return user;
}
