import React from 'react';

export default function Home() {
  return (
    <main>
      <section className="hero">
        <div className="hero-content">
          <h1>Handcrafted with Love by Hussan Bano</h1>
          <p>
            Discover unique, authentic handicrafts created with traditional
            techniques and modern designs
          </p>
          <div className="cta-buttons">
            <a href="/shop" className="btn btn-cta">
              Shop Now
            </a>
            <a href="/learn" className="btn btn-outline">
              Learn More
            </a>
          </div>
        </div>
        <div className="hero-image">
          <img
            src="https://images.unsplash.com/photo-1606722590583-6951b5ea92ad?w=400&h=400&fit=crop&q=80"
            alt="Colorful Handicrafts"
          />
        </div>
      </section>
      {/* TODO: Add Crafts, Workshops, Gallery sections as separate components */}
    </main>
  );
}
