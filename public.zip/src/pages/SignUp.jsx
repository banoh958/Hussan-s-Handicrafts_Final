import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  signOut
} from 'firebase/auth';
import { auth } from '../firebase-config';
import '../styles.css';

export default function SignUp() {
  const [fullname, setFullname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [interests, setInterests] = useState('');
  const [experience, setExperience] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');

    // Save pending profile until verification
    sessionStorage.setItem(
      'pendingProfile',
      JSON.stringify({ fullname, email, interests, experience, createdAt: new Date().toISOString() })
    );

    try {
      const { user } = await createUserWithEmailAndPassword(auth, email, password);
      await sendEmailVerification(user);
      alert(
        `Verification email sent to ${email}.\nPlease click the link in your inbox, then sign in.`
      );
      await signOut(auth);
      navigate('/signin');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <main>
      <nav className="navbar">
        <Link to="/" className="logo">
          <img
            src="https://i.ibb.co/Jd3tVbk/hussans-handicrafts-logo.png"
            alt="Hussan's Handicrafts Logo"
          />
          <span>Hussan's Handicrafts</span>
        </Link>
      </nav>

      <div className="container">
        <form onSubmit={handleSubmit} className="form" id="signup-form">
          <h1>Sign Up</h1>
          <p>Join Hussan's community of artisans and craft enthusiasts!</p>

          {error && <p className="form-error">{error}</p>}

          <div className="form-group">
            <label htmlFor="fullname">
              <i className="fas fa-user" /> Full Name:
            </label>
            <input
              type="text"
              id="fullname"
              value={fullname}
              onChange={e => setFullname(e.target.value)}
              required
              placeholder="Enter your full name"
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">
              <i className="fas fa-envelope" /> Email:
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              placeholder="Enter your email"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">
              <i className="fas fa-lock" /> Password:
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              placeholder="Create a password"
            />
          </div>

          <div className="form-group">
            <label htmlFor="interests">
              <i className="fas fa-heart" /> Craft Interests:
            </label>
            <select
              id="interests"
              value={interests}
              onChange={e => setInterests(e.target.value)}
              required
            >
              <option value="">Select Interest</option>
              <option value="pottery">Pottery & Ceramics</option>
              <option value="textile">Textile & Embroidery</option>
              <option value="woodwork">Woodwork & Carving</option>
              <option value="j jewelry">Handmade Jewelry</option>
              <option value="paper">Paper Craft & Origami</option>
              <option value="painting">Traditional Painting</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="experience">
              <i className="fas fa-star" /> Experience Level:
            </label>
            <select
              id="experience"
              value={experience}
              onChange={e => setExperience(e.target.value)}
              required
            >
              <option value="">Select Experience Level</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>

          <button type="submit" className="btn btn-cta">
            Sign Up
          </button>

          <p className="form-footer">
            Already have an account? <Link to="/signin">Sign in here</Link>
          </p>
        </form>
      </div>
    </main>
  );
}