// src/pages/SignIn.jsx
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { auth } from '../firebase-config';
import '../styles.css';

export default function SignIn() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');

    try {
      const { user } = await signInWithEmailAndPassword(auth, email, password);

      if (!user.emailVerified) {
        // Force logout if not verified
        await signOut(auth);
        setError('Email not verified. Please check your inbox.');
        return;
      }

      // Redirect to home/dashboard
      navigate('/');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <main>
      <nav className="navbar">
        {/* You can reuse your Navbar component here if preferred */}
        <Link to="/" className="logo">
          <img
            src="https://i.ibb.co/Jd3tVbk/hussans-handicrafts-logo.png"
            alt="Hussan's Handicrafts Logo"
          />
          <span>Hussan's Handicrafts</span>
        </Link>
      </nav>

      <div className="container">
        <form onSubmit={handleSubmit} className="form" id="signin-form">
          <h1>Sign In</h1>
          <p>Welcome back to Hussan's artisan community!</p>

          {error && <p className="form-error">{error}</p>}

          <div className="form-group">
            <label htmlFor="email">
              <i className="fas fa-envelope" /> Email:
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              placeholder="Enter your email"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">
              <i className="fas fa-lock" /> Password:
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              placeholder="Enter your password"
            />
          </div>

          <button type="submit" className="btn btn-primary">
            Sign In
          </button>

          <p className="form-footer">
            Don't have an account?{' '}
            <Link to="/signup">Sign up here</Link>
          </p>
        </form>
      </div>
    </main>
  );
}
