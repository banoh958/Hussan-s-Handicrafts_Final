import React from 'react';
import '../styles.css';

const teamMembers = [
  {
    name: "Hussan Bano",
    role: "Founder & Master Artisan",
    img: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400&h=400&fit=crop&q=80",
    bio: "Hussan founded Hussan's Handicrafts to preserve traditional techniques and train new artisans. With 15+ years of experience, she leads creative direction and mentorship.",
    specialties: ["Embroidery", "Pottery", "Textile Arts"]
  },
  {
    name: "Rahul Sharma",
    role: "Creative Director & Master Woodworker",
    img: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&h=400&fit=crop&q=80",
    bio: "Rahul oversees product development and quality control. His modern designs blend traditional woodcarving with contemporary aesthetics.",
    specialties: ["Woodcarving", "Furniture Design", "Inlay Work"]
  },
  {
    name: "Aisha Khan",
    role: "Senior Pottery Artist",
    img: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&h=300&fit=crop&q=80",
    bio: "Aisha has 12 years of pottery expertise, specializing in wheel throwing and glazing. Her pieces are known for intricate patterns and vibrant colors.",
    specialties: ["Wheel Throwing", "Glazing", "Clay Sculpture"]
  },
  {
    name: "Fatima Ahmed",
    role: "Paper Craft Specialist",
    img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&h=300&fit=crop&q=80",
    bio: "Fatima masters paper quilling and origami, creating delicate art that combines traditional patterns with contemporary design.",
    specialties: ["Quilling", "Origami", "Paper Sculpture"]
  }
];

export default function Team() {
  return (
    <main>
      <header className="page-hero team-hero">
        <div className="page-hero-content">
          <h1>Meet Our Artisan Team</h1>
          <p>The skilled hands and creative minds behind our beautiful handicrafts</p>
        </div>
      </header>

      <section className="leadership-team">
        <h2 className="section-title">Leadership Team</h2>
        <div className="leadership-container">
          {teamMembers.slice(0, 2).map((member, idx) => (
            <div key={idx} className="leader-card">
              <div className="leader-image">
                <img src={member.img} alt={member.name} />
              </div>
              <div className="leader-info">
                <h3>{member.name}</h3>
                <p className="leader-title">{member.role}</p>
                <p className="leader-bio">{member.bio}</p>
                <div className="leader-specialties">
                  {member.specialties.map((s, i) => <span key={i}>{s}</span>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="artisan-team">
        <h2 className="section-title">Our Artisans</h2>
        <div className="artisan-grid">
          {teamMembers.map((member, idx) => (
            <div key={idx} className="artisan-card">
              <div className="artisan-image">
                <img src={member.img} alt={member.name} />
              </div>
              <div className="artisan-info">
                <h3>{member.name}</h3>
                <p className="artisan-title">{member.role}</p>
                <p className="artisan-bio">{member.bio}</p>
                <div className="artisan-specialties">
                  {member.specialties.map((s, i) => <span key={i}>{s}</span>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="join-team">
        <div className="join-team-content">
          <h2>Join Our Team</h2>
          <p>Are you passionate about traditional handicrafts? We’re always looking for talented artisans to join our team. Whether you’re a master craftsperson or an enthusiastic apprentice, we’d love to hear from you.</p>
          <button className="btn btn-primary">Apply to Join</button>
        </div>
      </section>
    </main>
  );
}
