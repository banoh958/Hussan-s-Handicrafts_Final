// src/pages/Shop.jsx
import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase-config';
import {
  collection,
  addDoc,
  updateDoc,
  setDoc,
  doc,
  onSnapshot,
  serverTimestamp,
  getDoc,
} from 'firebase/firestore';
import '../styles.css';

export default function Shop() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({
    title: '',
    category: '',
    price: '',
    imageUrl: '',
    badge: '',
    originalPrice: '',
  });
  const [editingId, setEditingId] = useState(null);
  const user = auth.currentUser;

  // Real-time listener for products
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'products'), (snap) => {
      setProducts(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, []);

  // Add or update product
  const saveProduct = async (e) => {
    e.preventDefault();
    const data = {
      title: form.title,
      category: form.category,
      price: parseFloat(form.price),
      imageUrl: form.imageUrl,
      badge: form.badge,
      originalPrice: form.originalPrice
        ? parseFloat(form.originalPrice)
        : null,
      updatedAt: serverTimestamp(),
    };

    if (editingId) {
      await updateDoc(doc(db, 'products', editingId), data);
      setEditingId(null);
    } else {
      await addDoc(collection(db, 'products'), {
        ...data,
        createdAt: serverTimestamp(),
      });
    }

    setForm({
      title: '',
      category: '',
      price: '',
      imageUrl: '',
      badge: '',
      originalPrice: '',
    });
  };

  // Enter “edit” mode
  const startEdit = (p) => {
    setEditingId(p.id);
    setForm({
      title: p.title,
      category: p.category,
      price: p.price.toString(),
      imageUrl: p.imageUrl,
      badge: p.badge || '',
      originalPrice: p.originalPrice?.toString() || '',
    });
  };

  // Add to cart (fixed!)
  const addToCart = async (p) => {
    if (!user) return alert('Please sign in to add items to the cart.');

    const cartRef = doc(db, 'carts', user.uid);
    const cartSnap = await getDoc(cartRef);
    let items = [];

    if (cartSnap.exists()) {
      items = cartSnap.data().items || [];
      // merge existing
      items = [...items, p];
      await updateDoc(cartRef, { items });
    } else {
      // first time: create the doc
      items = [p];
      await setDoc(cartRef, {
        items,
        createdAt: serverTimestamp(),
      });
    }

    alert(`Added "${p.title}" to cart!`);
  };

  return (
    <div className="shop-page">
      <form className="admin-form" onSubmit={saveProduct}>
        <h2>{editingId ? 'Edit' : 'Add'} Product</h2>
        {['title', 'category', 'price', 'imageUrl', 'badge', 'originalPrice'].map((key) => (
          <input
            key={key}
            type={key.includes('price') ? 'number' : 'text'}
            step={key.includes('price') ? '0.01' : undefined}
            placeholder={key}
            value={form[key]}
            onChange={(e) => setForm({ ...form, [key]: e.target.value })}
            required={['title', 'category', 'price', 'imageUrl'].includes(key)}
          />
        ))}
        <button type="submit">{editingId ? 'Update' : 'Add'} Product</button>
      </form>

      <div className="grid">
        {products.map((p) => (
          <div key={p.id} className="product-card">
            {p.badge && <span className="badge">{p.badge}</span>}
            <img src={p.imageUrl} alt={p.title} />
            <h3>{p.title}</h3>
            <p>
              ${p.price.toFixed(2)}{' '}
              {p.originalPrice && <del>${p.originalPrice.toFixed(2)}</del>}
            </p>
            <button onClick={() => startEdit(p)}>Edit</button>
            <button onClick={() => addToCart(p)}>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}
