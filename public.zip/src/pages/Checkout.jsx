// src/pages/Checkout.jsx
import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase-config';
import { doc, onSnapshot, addDoc, collection, serverTimestamp, updateDoc } from 'firebase/firestore';
import '../styles.css';

export default function Checkout() {
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState('');
  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;
    const ref = doc(db, 'carts', user.uid);
    const unsub = onSnapshot(ref, snap => {
      setItems(snap.exists && snap.data().items ? snap.data().items : []);
    });
    return unsub;
  }, [user]);

  const placeOrder = async () => {
    setStatus('Placing order...');
    const order = { userId: user.uid, items, total: items.reduce((s,i) => s + i.price, 0), createdAt: serverTimestamp() };
    await addDoc(collection(db, 'orders'), order);
    await updateDoc(doc(db, 'carts', user.uid), { items: [] });
    setStatus('Order placed successfully!');
  };

  return (
    <div className="checkout-page">
      <h2>Checkout</h2>
      <ul>
        {items.map((i, idx) => <li key={idx}>{i.title} - ${i.price.toFixed(2)}</li>)}
      </ul>
      <h3>Total: ${items.reduce((s,i) => s + i.price, 0).toFixed(2)}</h3>
      <button onClick={placeOrder} disabled={!items.length || status.includes('...')}>
        Place Order
      </button>
      {status && <p>{status}</p>}
    </div>
  );
}
