import React from 'react';
import '../styles.css';

const workshopData = [
  {
    title: 'Pottery Workshop for Beginners',
    date: '15 Jun',
    time: '10:00 AM - 2:00 PM',
    price: '$45',
    location: "Hussan's Art Studio, Downtown",
    description: 'Learn the basics of pottery making with Hussan and create your own clay pot to take home.'
  },
  {
    title: 'Traditional Embroidery Techniques',
    date: '22 Jun',
    time: '1:00 PM - 4:00 PM',
    price: '$35',
    location: "Hussan's Craft Center, Westside",
    description: 'Master the art of traditional embroidery with Hussan and create beautiful patterns on fabric.'
  },
  {
    title: 'Paper Quilling Art Workshop',
    date: '29 Jun',
    time: '11:00 AM - 3:00 PM',
    price: '$30',
    location: 'Community Center, Eastside',
    description: 'Learn the delicate art of paper quilling with Hussan and create intricate designs and patterns.'
  }
];

export default function Learn() {
  return (
    <main>
      <header className="module-hero learners-hero">
        <div className="module-hero-content">
          <h1>Master the Art of Handicrafts</h1>
          <p>
            Join our workshops, courses, and apprenticeship programs to learn
            traditional handicraft techniques from expert artisans
          </p>
          <button
            onClick={() => (window.location.hash = '#workshops')}
            className="btn btn-cta pulse"
          >
            Explore Workshops
          </button>
        </div>
      </header>

      <section id="workshops" className="module-section">
        <h2 className="section-title">Upcoming Workshops</h2>
        <p className="section-description">
          Join our hands-on workshops and create beautiful handicrafts in just
          one session
        </p>

        <div className="workshop-cards">
          {workshopData.map((w, idx) => (
            <div key={idx} className="workshop-card">
              <div className="workshop-image">
                <div className="workshop-date">
                  <span className="day">{w.date.split(' ')[0]}</span>
                  <span className="month">{w.date.split(' ')[1]}</span>
                </div>
              </div>
              <div className="workshop-content">
                <h3>{w.title}</h3>
                <p className="workshop-details">
                  <i className="fas fa-map-marker-alt"></i> {w.location}
                </p>
                <p className="workshop-details">
                  <i className="fas fa-clock"></i> {w.time}
                </p>
                <p className="workshop-details">
                  <i className="fas fa-tag"></i> {w.price}
                </p>
                <p>{w.description}</p>
                <button className="btn btn-primary">Register Now</button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
