import React from 'react';
import { Link } from 'react-router-dom';
import '../styles.css';

export default function About() {
  return (
    <main>
      {/* Hero Section */}
      <section className="about-hero">
        <div className="about-content">
          <h1>About Hussan's Handicrafts</h1>
          <p>Discover the story behind our passion for traditional craftsmanship</p>
        </div>
      </section>

      {/* Main Content */}
      <div className="about-main">
        {/* Meet Section */}
        <section className="about-section">
          <div className="about-image">
            <img
              src="https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=500&h=500&fit=crop&q=80"
              alt="Hussan Bano"
            />
          </div>
          <div className="about-text">
            <h2>Meet Hussan Bano</h2>
            <p>
              Welcome to Hussan's Handicrafts, where tradition meets creativity.
              I'm Hussan Bano, a passionate artisan dedicated to preserving and
              celebrating the rich heritage of handcrafted art.
            </p>
            <p>
              My journey began over 15 years ago when I learned traditional
              embroidery techniques from my grandmother. What started as a family
              tradition has blossomed into a lifelong passion for creating
              beautiful, handcrafted items that tell stories and preserve cultural
              heritage.
            </p>
            <p>
              Each piece in our collection is handcrafted with love and attention
              to detail, using techniques passed down through generations and
              materials sourced from local communities.
            </p>
          </div>
        </section>

        {/* Mission Section */}
        <section className="mission-section">
          <h2 className="section-title">Our Mission</h2>
          <div className="mission-cards">
            <div className="mission-card">
              <div className="mission-icon">
                <i className="fas fa-hands"></i>
              </div>
              <h3>Preserve Traditions</h3>
              <p>
                We are committed to preserving traditional handicraft techniques
                that have been passed down through generations, ensuring these
                valuable skills are not lost to time.
              </p>
            </div>
            <div className="mission-card">
              <div className="mission-icon">
                <i className="fas fa-users"></i>
              </div>
              <h3>Empower Artisans</h3>
              <p>
                We work with local artisans to provide fair opportunities and
                support sustainable livelihoods through the celebration of
                traditional craftsmanship.
              </p>
            </div>
            <div className="mission-card">
              <div className="mission-icon">
                <i className="fas fa-leaf"></i>
              </div>
              <h3>Sustainable Practices</h3>
              <p>
                We are dedicated to using eco-friendly materials and sustainable
                practices in all our creations, respecting both tradition and our
                environment.
              </p>
            </div>
          </div>
        </section>

        {/* Journey Section */}
        <section className="journey-section">
          <h2 className="section-title">Our Journey</h2>
          <div className="timeline">
            {[
              {
                year: "2010",
                text: "Hussan's Handicrafts was born from a small home workshop focusing on traditional embroidery."
              },
              {
                year: "2015",
                text: "Expanded our craft offerings to include pottery, woodwork, and paper crafts, collaborating with local artisans."
              },
              {
                year: "2018",
                text: "Opened our first physical workshop and gallery space, allowing visitors to experience the crafting process."
              },
              {
                year: "2020",
                text: "Launched our online platform to share our handicrafts with a global audience and began offering virtual workshops."
              },
              {
                year: "2023",
                text: "Received national recognition for our contribution to preserving traditional handicraft techniques."
              }
            ].map((item, idx) => (
              <div key={idx} className="timeline-item">
                <div className="timeline-dot"></div>
                <div className="timeline-content">
                  <h3>{item.year}</h3>
                  <p>{item.text}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Team Section */}
        <section className="team-section">
          <h2 className="section-title">Our Artisan Team</h2>
          <div className="team-container">
            {[
              {
                name: "Hussan Bano",
                role: "Founder & Master Artisan",
                img: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=300&h=300&fit=crop&q=80",
                specialty: "Embroidery & Textile Arts"
              },
              {
                name: "Aisha Khan",
                role: "Senior Pottery Artist",
                img: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&h=300&fit=crop&q=80",
                specialty: "Wheel Throwing & Glazing"
              },
              {
                name: "Rahul Sharma",
                role: "Master Woodworker",
                img: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=300&h=300&fit=crop&q=80",
                specialty: "Woodcarving & Inlay Work"
              },
              {
                name: "Fatima Ahmed",
                role: "Paper Craft Specialist",
                img: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&h=300&fit=crop&q=80",
                specialty: "Paper Quilling & Origami"
              }
            ].map((member, idx) => (
              <div key={idx} className="team-member">
                <img src={member.img} alt={member.name} />
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <p>{member.specialty}</p>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-content">
          <h2>Join Our Handicraft Community</h2>
          <p>Experience the beauty of traditional craftsmanship and learn from skilled artisans</p>
          <Link to="/signup" className="btn btn-cta">
            Sign Up Now
          </Link>
        </div>
      </section>
    </main>
  );
}
