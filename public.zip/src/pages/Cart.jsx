// src/pages/Cart.jsx
import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase-config';
import { doc, onSnapshot, updateDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import '../styles.css';

export default function Cart() {
  const [items, setItems] = useState([]);
  const navigate = useNavigate();
  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;
    const ref = doc(db, 'carts', user.uid);
    const unsub = onSnapshot(ref, snap => {
      setItems(snap.exists && snap.data().items ? snap.data().items : []);
    });
    return unsub;
  }, [user]);

  const remove = async idx => {
    const ref = doc(db, 'carts', user.uid);
    const updated = items.filter((_, i) => i !== idx);
    setItems(updated);
    await updateDoc(ref, { items: updated });
  };

  return (
    <div className="cart-page">
      <h2>Your Cart</h2>      <ul>
        {items.map((i, idx) => (
          <li key={idx}>
            {i.title} - ${i.price.toFixed(2)}
            <button onClick={() => remove(idx)}>Remove</button>
          </li>
        ))}
      </ul>
      <button onClick={() => navigate('/checkout')} disabled={!items.length}>
        Checkout (${items.reduce((sum, x) => sum + x.price, 0).toFixed(2)})
      </button>
    </div>
  );
}