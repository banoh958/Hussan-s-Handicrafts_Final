import React, { useState } from 'react';
import '../styles.css';

const jobData = [
  {
    title: 'Senior Pottery Artisan',
    type: 'Full-time',
    category: 'artisan',
    location: 'Artisan City Studio',
    department: 'Pottery Department',
    responsibilities: [
      'Create high-quality pottery pieces for our collections',
      'Develop new designs that blend traditional techniques with contemporary aesthetics',
      'Mentor junior artisans and apprentices',
      'Maintain workshop equipment and supplies'
    ],
    requirements: [
      '5+ years of experience in pottery making',
      'Proficiency in various pottery techniques',
      'Strong portfolio demonstrating craftsmanship',
      'Ability to work collaboratively in a team environment'
    ]
  },
  {
    title: 'Textile Arts Instructor',
    type: 'Part-time',
    category: 'teaching',
    location: 'Craft Learning Center',
    department: 'Education Department',
    responsibilities: [
      'Develop and lead workshops and courses in textile arts',
      'Create curriculum materials and project guides',
      'Provide constructive feedback to students',
      'Maintain teaching supplies and equipment'
    ],
    requirements: [
      '3+ years of experience in textile arts',
      'Previous teaching experience preferred',
      'Excellent communication and interpersonal skills',
      'Patience and ability to work with diverse student groups'
    ]
  },
  {
    title: 'E-commerce Specialist',
    type: 'Full-time',
    category: 'business',
    location: 'Main Office',
    department: 'Marketing Department',
    responsibilities: [
      'Manage our online store and product listings',
      'Create compelling product descriptions and photography',
      'Implement digital marketing strategies to drive traffic and sales',
      'Analyze sales data and customer feedback to optimize performance'
    ],
    requirements: [
      '2+ years of experience in e-commerce or digital marketing',
      'Familiarity with e-commerce platforms and SEO',
      'Strong photography and copywriting skills',
      'Data analysis and problem-solving abilities'
    ]
  },
  {
    title: 'Junior Woodworking Artisan',
    type: 'Apprenticeship',
    category: 'artisan',
    location: 'Woodworking Studio',
    department: 'Woodcraft Department',
    responsibilities: [
      'Assist master woodworkers in creating handcrafted wooden items',
      'Learn traditional woodworking techniques and tool usage',
      'Help maintain workshop equipment and supplies',
      'Participate in production of small wooden items'
    ],
    requirements: [
      'Basic woodworking skills and knowledge',
      'Strong interest in traditional craftsmanship',
      'Willingness to learn and take direction',
      'Good manual dexterity and attention to detail'
    ]
  }
];

export default function Careers() {
  const [filter, setFilter] = useState('all');

  const filteredJobs = jobData.filter(job => filter === 'all' || job.category === filter);

  return (
    <main>
      <header className="module-hero careers-hero">
        <div className="module-hero-content">
          <h1>Join Our Artisan Community</h1>
          <p>Build a rewarding career preserving and celebrating traditional handicraft techniques</p>
          <button onClick={() => window.location.hash = '#openings'} className="btn btn-cta pulse">
            View Openings
          </button>
        </div>
      </header>

      <section className="careers-intro">
        <h2 className="section-title">Why Work With Us</h2>
        <p className="section-description">At Hussan's Handicrafts, we're passionate about preserving traditional craftsmanship while embracing innovation</p>
        {/* Add benefits grid if needed */}
      </section>

      <section id="openings" className="module-section">
        <h2 className="section-title">Current Openings</h2>
        <div className="job-filters">
          {['all', 'artisan', 'teaching', 'business'].map(cat => (
            <button
              key={cat}
              className={`job-filter ${filter === cat ? 'active' : ''}`}
              onClick={() => setFilter(cat)}
            >
              {cat === 'all' ? 'All Positions' : cat.charAt(0).toUpperCase() + cat.slice(1)}
            </button>
          ))}
        </div>

        <div className="job-listings">
          {filteredJobs.map((job, idx) => (
            <div key={idx} className="job-card">
              <div className="job-header">
                <h3>{job.title}</h3>
                <span className={`job-type ${job.category}`}>{job.type}</span>
              </div>
              <div className="job-details">
                <p className="job-location"><i className="fas fa-map-marker-alt"></i> {job.location}</p>
                <p className="job-department"><i className="fas fa-briefcase"></i> {job.department}</p>
              </div>
              <div className="job-description">
                <h4>Responsibilities:</h4>
                <ul>{job.responsibilities.map((r, i) => <li key={i}>{r}</li>)}</ul>
                <h4>Requirements:</h4>
                <ul>{job.requirements.map((r, i) => <li key={i}>{r}</li>)}</ul>
              </div>
              <button className="btn btn-primary">Apply Now</button>
            </div>
          ))}
        </div>
      </section>

      <section className="internship-section bg-light">
        <h2 className="section-title">Internship Program</h2>
        <p className="section-description">Gain valuable experience in traditional craftsmanship and business operations</p>
        {/* Internship content here if needed */}
      </section>
    </main>
  );
}
