// src/firebase-config.js
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: 'AIzaSyDrAdMjN356f5KRuthGUjgMeegUnxzFR2M',
  authDomain: 'hussan-shandicraft.firebaseapp.com',
  projectId: 'hussan-shandicraft',
  storageBucket: 'hussan-shandicraft.firebasestorage.app',
  messagingSenderId: '701854217681',
  appId: '1:701854217681:web:9c1954d0cb9b0710ee1cf0',
  measurementId: 'G-4WPXK20M8Z'
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export Firebase services for use in other parts of your app
export const auth = getAuth(app);
export const db = getFirestore(app);
