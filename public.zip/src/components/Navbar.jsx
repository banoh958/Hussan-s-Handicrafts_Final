import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { auth, db } from '../firebase-config';
import { onSnapshot, doc } from 'firebase/firestore';
import '../styles.css';

export default function Navbar() {
  const [cartCount, setCartCount] = useState(0);
  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return setCartCount(0);
    const cartRef = doc(db, 'carts', user.uid);
    const unsub = onSnapshot(cartRef, snap => {
      setCartCount(snap.exists() && snap.data().items ? snap.data().items.length : 0);
    }, err => {
      console.error('Cart snapshot error:', err);
    });
    return unsub;
  }, [user]);
  return (
    <nav className="navbar">
      <div className="logo">
        <Link to="/">
          <img
            src="https://i.ibb.co/Jd3tVbk/hussans-handicrafts-logo.png"
            alt="Hussan's Handicrafts Logo"
          />
          <span>Hussan's Handicrafts</span>
        </Link>
      </div>
      <ul className="nav-links">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/learn">Learn</Link></li>
        <li><Link to="/shop">Shop</Link></li>
        <li><Link to="/careers">Careers</Link></li>
        <li><Link to="/about">About</Link></li>
        <li><Link to="/team">Our Team</Link></li>
        <li><Link to="/shop">Shop</Link></li>
        <li><Link to="/cart">Cart ({cartCount})</Link></li>
      </ul>
      <div className="auth-buttons">
        <Link to="/signin" className="btn btn-primary">Sign In</Link>
        <Link to="/signup" className="btn btn-secondary">Sign Up</Link>
      </div>
    </nav>
  );
}
